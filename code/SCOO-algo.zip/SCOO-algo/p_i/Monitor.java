package p_i;
import importPackage.*;

public interface Monitor extends PrettyPrint {

	public Monitor createMonitor();
	public void setCallbacker(CallBacker c);
	public boolean isLocked();
	public boolean lock();
	public void addCallBackers(CallBacker c1, CallBacker c2);
	public CallBacker trick(boolean b);
	public Monitor spawn();
}
