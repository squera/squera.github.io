package p_i;

public interface PrettyPrint {

	public int prettyPrint();
}
