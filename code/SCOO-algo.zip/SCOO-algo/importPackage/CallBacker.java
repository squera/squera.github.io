package importPackage;
import p_i.*;

public interface CallBacker {

	public void callback(Monitor m);
	public void callTwo(Integer s);
	public void callThree(Monitor m);
	public CallBacker createCallBacker();
	public void trickBack(CallBacker c1, CallBacker c2);
	
}
