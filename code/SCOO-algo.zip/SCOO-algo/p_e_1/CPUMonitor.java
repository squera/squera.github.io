package p_e_1;

import algOut.CallBacker_c;
import importPackage.*;
import p_i.*;

public class CPUMonitor implements Monitor{
	public static CPUMonitor staticMonitor = new CPUMonitor();
	private CallBacker cb = null;
	private boolean lock = true;
	private int buffer = 0;
	private int lockcounter=0;

	@Override
	public int prettyPrint() {
		return buffer;
	}

	@Override
	public Monitor createMonitor() {
		return CPUMonitor.staticCreateMonitor();
	}

	@Override
	public void setCallbacker(CallBacker c) {
		if(c==null){
			CallBacker o = CallBacker_c.staticCallBacker.createCallBacker();
			System.out.println("asd ");
			o.callTwo(buffer);
			return;
		}
		cb = c;
		cb.callback(this);
	}

	@Override
	public boolean isLocked() {
		return lock;
	}

	private static Monitor staticCreateMonitor(){
		return new CPUMonitor();
	}

	@Override
	public boolean lock() {
		if(lockcounter==0){
			lockcounter++;
			lock = true;
			return true;
		}else{
			return false;
		}
	}

	@Override
	public void addCallBackers(CallBacker c1, CallBacker c2) {
		if(c1 == null){
			System.exit(0);
		}
		if(c1 == c2){
			return;
		}
		c1.callThree(this);
	}

	@Override
	public CallBacker trick(boolean b) {
		CallBacker c1 = CallBacker_c.staticCallBacker.createCallBacker();
		CallBacker c2 = CallBacker_c.staticCallBacker.createCallBacker();
		if(b){
			return c2;
		}else{
			c1.trickBack(c1, c2);
		}
		return null;
	}

	@Override
	public Monitor spawn() {
		Monitor c = this.createMonitor();
		return c;
	}


}
