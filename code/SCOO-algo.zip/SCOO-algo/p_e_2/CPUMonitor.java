package p_e_2;

import algOut.CallBacker_c;
import importPackage.*;
import p_i.*;

public class CPUMonitor implements Monitor{
	public static CPUMonitor staticMonitor = new CPUMonitor();
	private CallBacker cb = null;
	private boolean lock = false;
	private int buffer = 1;

	@Override
	public int prettyPrint() {
		return buffer;
	}

	@Override
	public Monitor createMonitor() {
		return CPUMonitor.staticCreateMonitor();
	}

	@Override
	public void setCallbacker(CallBacker c) {
		if(c==null){
			CallBacker o = CallBacker_c.staticCallBacker.createCallBacker();
			o.callTwo(buffer);
			return;
		}
		cb = c;
		Monitor o = staticCreateMonitor();
		cb.callback(o);
	}

	@Override
	public boolean isLocked() {
		return lock;
	}
	
	private static Monitor staticCreateMonitor(){
		return new CPUMonitor();
	}

	@Override
	public boolean lock() {
		lock = true;
		return true;
	}

	@Override
	public void addCallBackers(CallBacker c1, CallBacker c2) {
		if(c2 == null){
			c2 = CallBacker_c.staticCallBacker.createCallBacker();
		}
		c2.callThree(this);
	}
	@Override
	public CallBacker trick(boolean b) {
		CallBacker c1 = CallBacker_c.staticCallBacker.createCallBacker();
		CallBacker c2 = CallBacker_c.staticCallBacker.createCallBacker();
		if(b){
			return c1;
		}else{
			c1.trickBack(c2, c1);
		}
		return null;
	}
	@Override
	public Monitor spawn() {
		Monitor c = this.createMonitor();
		return c;
	}

}
