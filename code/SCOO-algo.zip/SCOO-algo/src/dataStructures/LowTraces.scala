package dataStructures

sealed abstract trait LowTraces {}

sealed abstract trait InputTrace extends LowTraces{
  override def toString()={
    "?"
  }
}
sealed abstract trait OutputTrace extends LowTraces{
  override def toString()={
    "!"
  }
}

sealed abstract trait Calls {
  protected var a:List[String] = Nil
  var m: String= ""
  
  def caller():String ={
    a.head
  }
  def callArgs():List[String]={
    a.tail
  }
  override def toString():String = {
    return "Call "+m+"("+a.foldRight("")((a,b)=>a+","+b)+")"+ super.toString()
  }
}

sealed case class Call(meth:String,protected var arg:List[String]) extends InputTrace with Calls{
  a=arg
  m=meth
  override def toString():String={
    return super.toString()
  }
}
sealed case class Returnback(var arg:String) extends InputTrace {
  override def toString():String={
    return "ret "+arg+super.toString()
  }
}

sealed case class Callback(meth:String,protected var arg:List[String]) extends OutputTrace with Calls{
  a=arg
  m=meth
  override def toString():String={
    return super.toString()
  }
  
  def argsToStr()={
    arg.foldRight("")((a,b)=>(a+b+""))
  }
  def sameCaller(c:Callback):Boolean = {
    this.caller().equalsIgnoreCase(c.caller())
  }
  
  def isEqualTo(c:Callback):Boolean ={
    return (m.equalsIgnoreCase(c.m) && (this.argsToStr().equalsIgnoreCase(c.argsToStr())))
  }
}
sealed case class Return(var arg:String) extends OutputTrace{
  override def toString():String={
    return "ret "+arg+super.toString()
  }
}