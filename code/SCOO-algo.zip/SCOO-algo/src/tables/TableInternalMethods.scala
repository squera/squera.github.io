package tables

//internal methods
object TableInternalMethods {

  //all the methods defined in the interfaces of p_i with their information
  private var entries: List[MethEnt] = Nil
  
  
  def setupEntries ()={
    entries =(new MethEnt("prettyPrint",0,Nil,"int","PrettyPrint")):: (new MethEnt("createMonitor",0,Nil,"Monitor","Monitor"))::(new MethEnt("setCallbacker", 1, "CallBacker" :: Nil, "Unit","Monitor"))::(new MethEnt("isLocked",0,Nil,"Boolean","Monitor"))::(new MethEnt("lock",0,Nil,"Boolean","Monitor"))::(new MethEnt("addCallBackers",2,"CallBacker"::"CallBacker"::Nil,"Unit","Monitor"))::(new MethEnt("trick", 1, "Boolean"::Nil, "CallBacker","Monitor"))::(new MethEnt("spawn", 0,Nil,"Monitor","Monitor"))::Nil
  }
  
  def getElWithName(n:String):MethEnt={
    var ret = entries.filter((a)=>(a.methName.equalsIgnoreCase(n)))
    if(ret == Nil){
      null
    }else{
      ret.head
    }
  }
  
}


// important, do not use int, bool etc for the types, use Integer etc etc
class MethEnt(val methName:String, val numArgs:Int,val argTypes:List[String], val retType:String, val intfDefinig:String){
  
}
