package tables

//this is a table that captures inheritance among the interfaces of teh components under test
object TableInternalInterfaces {

  //each entry is a pair
  //the first is the name of the interface
  //the second is the list of interfaces it implements *directly*
  private var entries:List[Pair[String,List[String]]] = Nil
  
  
  def setupEntries()={
    entries = ("Monitor","PrettyPrint"::Nil)::("PrettyPrint",Nil)::Nil
  }
  
  def exposeEntries()={
    entries
  }
  
  def isInternallyDefined(s:String):Boolean={
    return (entries.filter((a)=>(a._1.equalsIgnoreCase(s))).length > 0)
  }
  
  def getEntryByName(s:String):Pair[String,List[String]]={
    var app = entries.filter((a)=>(a._1.equalsIgnoreCase(s)))
    if (app == Nil){
      ("",Nil)
    }else{
      app.head
    }
  }
}