package tables


//this is the table of external methods
object TableExternalMethods{
  private var entries: List[ExtMethEnt] = Nil
  
  def setupEntries()={
    entries =(new ExtMethEnt("main",0,Nil,"Unit",Nil,"Tester"))::(new ExtMethEnt("callback", 1, "Monitor"::Nil,"Unit","m"::Nil,"CallBacker"))::(new ExtMethEnt("callTwo", 1, "Integer"::Nil, "Unit","s"::Nil,"CallBacker"))::(new ExtMethEnt("callThree",1, "Monitor"::Nil, "Unit","m"::Nil,"CallBacker"))::(new ExtMethEnt("createCallBacker", 0, Nil, "CallBacker",Nil,"CallBacker"))::(new ExtMethEnt("trickBack", 2, "CallBacker"::"CallBacker"::Nil, "Unit","c1"::"c2"::Nil,"CallBacker"))::Nil
  }
  
  def exposeEntries()={
    entries
  }
  
  def getReturnType(s:String):String = {
    if(getElemByName(s) == null){
      ""
    }else{
      getElemByName(s).retType
    }
  }
  
  def getTypeOf(s:String,n:Int):String = {
    if(getElemByName(s) == null){
      ""
    }else{
      getElemByName(s).argTypes(n)
    }
  }
  
  def getElemByName(s:String):ExtMethEnt={
    var v = entries.filter((a)=>(a.methName.equalsIgnoreCase(s)))
    if(v == Nil){
      null
    }else{
      v.head
    }
  }
}



class ExtMethEnt(val m:String, val n:Int,val a:List[String], val r:String,  val argNames : List[String], val i : String)extends MethEnt(m,n,a,r,i){
  
}