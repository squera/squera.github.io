package tables
import main._

//table AO from the paper
object TableAO {
	
  private var entries: List[EntryAO] = Nil
  private var statics: List[EntryAO] = Nil
  
  def setupEntries()={
    entries =(new EntryAO(Main.SMA,"Monitor"::"PrettyPrint"::Nil,"CPUMonitor.staticMonitor"))::(new EntryAO(Main.SCBA,"CallBacker"::Nil,"CallBacker_c.staticCallBacker"))::Nil
    statics =(new EntryAO(Main.SMA,"Monitor"::"PrettyPrint"::Nil,"CPUMonitor.staticMonitor"))::(new EntryAO(Main.SCBA,"CallBacker"::Nil,"CallBacker_c.staticCallBacker"))::Nil
  }
  
  def add( e:EntryAO) ={
    entries = entries ++ (e :: Nil)
  }
  
  def getStaticName(s:String):String={
    var app = statics.filter((a)=>(a.v.equalsIgnoreCase(s)))
    if(app == Nil){
      return ""
    }
    return app.head.hln
  }
  
 def getClassOf(s:String):String={
   var app = entries.filter((a)=>(a.v.equalsIgnoreCase(s)))
   if(app == Nil){
     AlgBody.panic("entry with name "+s+" not found in AO")
   }
   app.head.getMyClass()
 }
  
}





//entries of the table
class EntryAO(val v:String,val types: List[String], val hln : String) {
  if(types==Nil){
    println("Entry in AO without types")
    System.exit(1)
  }
  var classOfEntry:String = types.head
  if(!types.head.equalsIgnoreCase("Tester")){
    classOfEntry = classOfEntry+"_c"
  }
  
  override def toString()={
    v+" WN "+hln+" : "+classOfEntry+" ("+types.foldRight("")((a,b)=>(a+b))+")"
  }
  
  //if there is only one of the type t in the list of types, then the entry has type t
  def hasType(t:String):Boolean ={
    if(types.filter((s)=>s.equalsIgnoreCase(t)).length >= 1){
      return true
    }
    return false
  }
  
  def hasValue(s:String):Boolean={
    return v.equalsIgnoreCase(s)
  }
  
  def getMyClass():String={
    classOfEntry
  }
}