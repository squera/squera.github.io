package tables

import java.io.PrintWriter
import java.io.File
import main.AlgBody

object TableExtMethBodies {
  
  // use TableExternalMethods
  private var entries: List[MYPair] = Nil
  
  def setupEntries()={
    entries = Nil
    for(el <- TableExternalMethods.exposeEntries()){
      var app = el.intfDefinig
      if(!app.equalsIgnoreCase("tester")){
        app = app+"_c"
      }
      entries = new MYPair(app,el.methName,"") ::entries
    }
  }
  
  //adds string s to method called m
  def addBody(i:String,m:String,s:String)={
    entries.filter((a)=>(a.me.equalsIgnoreCase(m) && a.in.equalsIgnoreCase(i))).head.bd+=s
  }
  

  
  //TODO here perform the write out
  def printOut(n:Int)={
    val writer = new PrintWriter(new File("./algOut/CallBacker_c.java"))

      writer.write("package algOut; \n" +
      		"import algOut.Listable;\n" +
      		"import p_i.*;\n" +
      		"import importPackage.CallBacker;\n" +
      		"import p_e_"+n+".*;\n" +
      		"\n"+
      		"public class CallBacker_c extends Listable implements CallBacker {\n"+
      		"\n"+
      		"public static CallBacker_c staticCallBacker = new CallBacker_c();\n" +
      		"\n")
      for(el <- entries){
        if(el.in.equalsIgnoreCase("CallBacker_c")){
          var ent = TableExternalMethods.getElemByName(el.me)
          var rt = ent.retType
          if(rt.equalsIgnoreCase("Unit")){
            rt = "void"
          }
          writer.write("public "+rt+" "+ent.methName+"( ")
          for( i <- 0 to (ent.numArgs-1)){
            writer.write(ent.argTypes(i)+" "+ent.argNames(i))
            if(i<(ent.numArgs-1)){
              writer.write(", ")
            }
          }
          writer.write(" ) {\n" +
          		""+el.bd+"\n")
          if(AlgBody.isNotGround(rt)){
        		  writer.write("return null;\n")
          }/*
          if(ent.methName.equalsIgnoreCase("createCallBacker")){
            writer.write("return new CallBacker_c();")
          }else{
        	  
          }*/
          writer.write("}\n")
        }
      }
      writer.write("public CallBacker defaultCreateClass_CallBacker(){\n" +
      		"\tif(this == CallBacker_c.staticCallBacker){\n" +
      		"\t\treturn new CallBacker_c();\n" +
      		"\t}\n" +
      		"//This should never happen actually\n" +
      		"\treturn new CallBacker_c();\n" +
      		"}\n")
      writer.write("}\n")
      writer.close()
    
      val wr2= new PrintWriter(new File("./algOut/Tester.java"))
      wr2.write("package algOut;\n" +
      		"\n" +
      		"import importPackage.CallBacker;\n" +
      		"import p_i.*;\n" +
      		"import p_e_"+n+".*;\n" +
      		"\n" +
      		"public class Tester extends Listable {\n" +
      		"\n" +
      		"public static void main(String[] args) {\n")
      for(el <- entries){// i know there will be only main here
        if(el.in.equalsIgnoreCase("Tester")){
          var ent = TableExternalMethods.getElemByName(el.me)
          wr2.write(el.bd+"\n")
      	}
      }
      wr2.write("}\n" +
      		"}\n")
      wr2.close()
    //entries.map((a)=>(println("Body of method "+a.me+" defined in class: "+a.in+" =\n"+a.bd)))
  }
}






// me is teh method name
// bd is the body
// in is the interface( or the class?)
class MYPair(val in : String, val me:String, var bd:String){
  override def toString()={
    in+"."+me+" "+bd
  }
  
}