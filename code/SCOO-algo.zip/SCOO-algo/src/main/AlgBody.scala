package main

import scala.util.control.Breaks._
import dataStructures._
import tables._

class AlgBody {
  
	//dynamic data structures
  var counter :Int =0 				// in the paper, this is i
  var diffL = 0
  var differentiated = false 		//a flag that tells me when to stop considering actions
  	//the following is a stack of pairs, the first is the name, the second is the type
  var expectedReturns: List[Pair[String,String]] = Nil
  	//elements of this list have the form X.Y where X is a class name and M is a method name
  var methInv : List[String] = "Tester.main"::Nil	// stack of method invocations. in the paper this is c.m
  var tabMethBodies = TableExtMethBodies	//list used to write the output
  var tabAO = TableAO // table AO, table with all dynamically allocated objects
  	//static data structures
  var tabIntMeth = TableInternalMethods		//is a list describing methods that can be called in the component
  var tabExtMeth = TableExternalMethods	//list describing methods in the external component
  var tabInterf = TableInternalInterfaces  	 
  var fresher = FreshNamer
  
  var a1:List[LowTraces] = Nil
  var a2:List[LowTraces] = Nil
  
  

	/*
	 * skip the part where it creates the classes for each interface in the export package
	 *  access class CallBacker_c and Tester directly
	 * 
	 * skip the part where the low-level addresses of methods are converted to real methods,
	 *  find high-level method names in traces already
	 */
	    
  def diff(a11:List[LowTraces], a21:List[LowTraces])={
    a1 = a11
    a2 = a21
    tabIntMeth.setupEntries()
    tabExtMeth.setupEntries()
    tabMethBodies.setupEntries()
    tabInterf.setupEntries()
    tabAO.setupEntries()
    
    while(a1.length > 0 && !differentiated){
    	constructionPhase(a1.head, a2.head)		//TODO is the calling ok?
    }
    if(diffL != 0){
      tabMethBodies.addBody("Tester","main","System.out.println("+diffL+");System.exit("+diffL+");")
    }
  }
  
  
  
  
  //here they must have the same type
  def constructionPhase(el1:LowTraces, el2:LowTraces):String={
    var ret = ""
    popActions()						//only pops if both are greater than Nil
    var app:LowTraces = null			//detect different length in traces
    if(a1==Nil){
      app = null
    }else{
      app=a1.head
    }
    var epp:LowTraces = null
    if(a2==Nil){
      epp = null
    }else{
      epp=a2.head
    }
    var thisClass = onlyCClass()			//save the current class and method
    var thisMeth = onlyCMethod()			//because execution can change them
    var str = "if ( Helper.oc.getStep() == "+counter+" ) {\n"
    str += "\tHelper.oc.incrementStep();\n"
    el1 match{				//assume el2 has the same type of el1
      case el:Call =>{ 
        for(i <- 0 to (el.callArgs().length-1)){
          var tp = tabIntMeth.getElWithName(el.meth).argTypes(i)
          str += "\t"+tp+" x"+i+" = ( "+tp+" ) "+llValLifting(el.callArgs()(i),tp)+";\n" // insert a cast to correctly retrieve internal objects from the list of objects
          if(AlgBody.isNotGround(tp) && !tabInterf.isInternallyDefined(tp) && !el.callArgs()(i).equalsIgnoreCase("null")){
            str += "\tif ( x"+i+" == null ) {\n"
            str += "\t\tx"+i+" = "+getStaticObjectForType(tp)+".defaultCreateClass_"+tp+"();\n"
            str += "\t\t( ("+tp+"_c) x"+i+").setOcAndNameAndRegister( \""+el.callArgs()(i)+"\" , \""+tp+"\" );\n" // if the object is not ground nor internal, add it to the list of external objects
            str += "\t}\n"
            tabAO.add(new EntryAO(el.callArgs()(i),tp::Nil,"x"+i))
          }
        }
        var ty = tabIntMeth.getElWithName(el.meth).retType
        var name = ""
        if(!ty.equalsIgnoreCase("unit")){
          name = fresher.getFreshName()
          str += "\t"+ty+" "+name+" = "
        }
        str += "\t"+llValLifting(el.caller(),tabIntMeth.getElWithName(el.meth).intfDefinig)+"."+el.meth+"( "
        for(i <- 0 to (el.callArgs().length-1)){
          str += "x"+i
          if(i < (el.callArgs().length-1)){
            str += ","
          }
        }
        str += " );\n"
        if(!name.equalsIgnoreCase("")){
          pushExpectedReturns(name,ty)
        }
        counter+=1
        var exeRet = executionPhase(app,epp)	//get possible code from execution
        str += "\t"+exeRet+"\n" 
      }
      case el:Returnback=>{
        var tp = tabExtMeth.getElemByName(onlyCMethod()).retType	//get the curr meth's ret type
        var name = fresher.getFreshName()
        str += "\t"+tp+" "+name+" = ( "+tp+" ) "+llValLifting(el.arg,tp)+";\n" //T + fresher = (T) + ll (el.arg. T
        if(AlgBody.isNotGround(tp) && !tabInterf.isInternallyDefined(tp)){  //if is not ground and is not internal T, if it is internal we are sure we'll get it from the llval function because it was returned fro ma call to the related factory method
            str += "\tif ( "+name+" == null ) {\n"
            str += "\t\t"+name+" = "+getStaticObjectForType(tp)+".defaultCreateClass_"+tp+"();\n"
            str += "\t\t( ("+tp+"_c) "+name+").setOcAndNameAndRegister( \""+el.arg+"\" , \""+tp+"\" );\n" // if the object is not ground nor internal, add it to the list of external objects
            str += "\t}\n"
            tabAO.add(new EntryAO(el.arg,tp::Nil,name))
          }
        str += "\treturn "+name+";\n"	//return o
        counter+=1
        popCurrentMethod()			
        ret = executionPhase(app,epp)	
      }
      case el:OutputTrace =>{
       AlgBody.panic("wrong kind of action in construction phase "+el)
      }
    }
    str+="}\n"
    this.tabMethBodies.addBody(thisClass,thisMeth,str)	//write to the right method body
    ret
  }
  
  
  
  //return what is expected from the construction phase, so it writes stuff in the location
  //set flag `differentiated' if the differentiating code has been written
  def executionPhase(el1:LowTraces, el2 : LowTraces):String={
    var ret = ""
    if(el1 == null && el2 == null){
      AlgBody.panic("WTF? two null traces in execution?")
      return ret
    }
    //if only one exists
    if(el1 == null){
      differentiated = true;
      diffL = 3
      return singleAction(el2,2)
    }
    if(el2 == null){
      differentiated = true;
      diffL = 2
      return singleAction(el1,3)
    }
    //this is executed only if both exist
    (el1,el2) match{
      case (e:Return,f:Return)=>{
        var nm = this.popExpectedReturns()._1
        var tp = this.popExpectedReturns()._2
        if(e.arg.equalsIgnoreCase(f.arg)){
          ret = "Helper.oc.incrementStep();\n"
          if (tabInterf.isInternallyDefined(tp)){ //if what i get back is defined internally
            //i add it to the table of help 
            ret += "\tHelper.oc.addInternalObject( \""+e.arg+"\" , \""+tp+"\" , "+nm+" );\n" 
        	tabAO.add(new EntryAO(e.arg, allInterfs(tp),nm))
          }
          popActions()
          counter += 1
        }else{
          ret = "if ( "+nm+" == "+llValLifting(e.arg,tp) +" ) { System.exit(3); } else { System.exit(2); }\n"
          differentiated = true;
        }
      }
      case (e:Callback, f:Callback) => {
        if(e.isEqualTo(f)){
          var str = "if ( Helper.oc.getStep() == "+counter+" ) {\n"
          str += "\tHelper.oc.incrementStep();\n"
          var cla = tabAO.getClassOf(e.caller())
          pushCurrentMethod(cla+"."+e.meth) //change CM
          for (i <- 0 to (e.callArgs().length -1)){
            var tp = tabExtMeth.getElemByName(e.callArgs()(i)).argTypes(i)
            if (tabInterf.isInternallyDefined(tp)) {
              var nm = tabExtMeth.getElemByName(e.callArgs()(i)).argNames(i)
              tabAO.add(new EntryAO(e.callArgs()(i), allInterfs(tp), nm))
              str += "\tHelper.oc.addInternalObject( \""+e.callArgs()(i)+"\" , \""+tp+"\" , "+nm+" );\n"
            }
          }
          str += "}\n"
          this.tabMethBodies.addBody(onlyCClass(), onlyCMethod(), str)
          popActions()
          counter += 1
          ret = constructionPhase(a1.head, a2.head)
        } else {
          var cla = tabAO.getClassOf(e.caller())
          if (e.meth.equalsIgnoreCase(f.meth)) { // i know the method names are equal here
            if (e.sameCaller(f)) { // difference in arguments
              breakable {
                for( i <- 0 to (e.callArgs().length-1)){
                  if(!e.callArgs()(i).equalsIgnoreCase(f.callArgs()(i))){ //difference found in element i
                    var meh = tabExtMeth.getTypeOf(e.meth,i)
                    var str = "if ( Helper.oc.getStep() == "+counter+" ) {\n"
                    var mn = tabExtMeth.getElemByName(e.meth).argNames(i)
                    if(!AlgBody.isNotGround(meh)){
                      str += "\tif ( "+mn+" == "+llValLifting(e.callArgs()(i),meh) +" ) { System.exit(3); } else { System.exit(2); }\n"
                    }else{
                      if(tabInterf.isInternallyDefined(meh)){
                        str += "\tif ( Helper.oc.getInternalByObject( "+mn+" ).equalsIgnoreCase( \""+e.callArgs()(i)+"\" ) ) { System.exit(3); } else { System.exit(2); }\n"
                      }else{
                        str += "\tif ( ((Listable)"+mn+").getName().equalsIgnoreCase( \""+e.callArgs()(i)+"\" ) ) { System.exit(3); } else { System.exit(2); }\n"
                      }
                    }
                    str+="}\n"
                    tabMethBodies.addBody(cla,e.meth,str)
                    break
                  }
                }
              }
            }else{// difference in the obj on which the meth is being called, still same class though
              var str = "if ( Helper.oc.getStep() == "+counter+" ) {\n"
              	str += "\tif ( this.getName().equalsIgnoreCase( \""+e.caller()+"\" ) ) { System.exit(3); } else { System.exit(2); }\n"
              	str += "}\n"
              tabMethBodies.addBody(cla,e.meth, str)
            }
          }else{ //different method names (covers also for different classes of the caller)
            var str = "if ( Helper.oc.getStep() == "+counter+" ) { System.exit(3); }\n"
            tabMethBodies.addBody(cla,e.meth,str)
            cla = tabAO.getClassOf(f.caller())
            str = "if ( Helper.oc.getStep() == "+counter+" ) { System.exit(2); }\n"
            tabMethBodies.addBody(cla,f.meth,str)
          }
          differentiated = true;
        }
      }
      case (e:Return,f:Callback)=>{
        ret = singleAction(e,3)
        singleAction(f,2)
        differentiated = true;
      }
      case (e:Callback,f:Return)=>{
        singleAction(e,3)
        ret = singleAction(f,2)
        differentiated = true;
      }
      case (e,f) => {
        AlgBody.panic("wrong kind of action considered in execution phase")
      }
    }
    return ret 
  }
  

  
  /***********************
   * Auxiliary functions
   */
  
  def llValLifting(v:String,t:String) : String = {
    var ret = ""
    t.toLowerCase() match{
      case "unit" => {
        ret=""				// check this, should it be empty always? well, it's never on the lhs
      }
      case "integer" => {
        ret=v
      }
      case "string" =>{
        ret = "\""+v+"\""
      }
      case "boolean" => {
        v match{
          case "0" => {
            ret="false"
          }
          case "1" => {
            ret="true"
          }
          case _ => {
            AlgBody.panic("malformed boolean, it's not 0 nor 1")
          }
        }
      }
      case _ => {
        var app = tabAO.getStaticName(v)
        if(!app.equalsIgnoreCase("")){
        	ret = app
        }else{
	        if(tabInterf.isInternallyDefined(t)){
	          ret = "( ( "+t+" ) Helper.oc.getInternalByName( \""+v+"\" ) )"
	        }else{
	          ret = "( ( "+t+" ) Helper.oc.getExternalByNameAndType( \""+v+"\" , \""+t+"\" ) )" 
	          /*
	           * i need the type here because teh external code could supply the same address to two methods that expect different type
	           * the high level code needs to know what correct object to supply
	           */
	        }
        }
      }
    }
    ret
  }
  
  /*  create a table where a high-level type (s) is linked to the name of the static object implementing it
   * this is for all externally defined interfaces
   */
  def getStaticObjectForType(s:String):String={
    s.toLowerCase() match{
      case "callbacker" =>{
        "CallBacker_c.staticCallBacker"
      }
      case "monitor" =>{
        "CPUMonitor.staticMonitor"
      }
      case a =>{
        AlgBody.panic("there is no static object for class "+s);
        ""
      }
    }
  }
  
  /*
   *  returns the return type of the current method
   * 
   * look for them in object TableExternalMethods :tabExtMeth
   */
  def currentReturnType():String={
    var nm = this.onlyCMethod()				//get only the method part
    return tabExtMeth.getReturnType(nm)   // ask for the object
  }
  
 
  
  
  
  
  
  
  /*
   * Auxiliary functions that are not mentioned in the paper but simplify my work
   */
  
  def pushCurrentMethod(s:String) = {
    this.methInv = s :: methInv
  }
  def popCurrentMethod():String={ 
    var ret = methInv.head
    this.methInv = methInv.tail
    ret
  }
  
  //call after the two heads have been considered
  def popActions()={
    if(a1 != Nil && a2 != Nil){
    	this.a1 = a1.tail
    	this.a2 = a2.tail
    }
  } 
  
  def pushExpectedReturns(s:String,t:String)={
    this.expectedReturns = (s,t)::expectedReturns
  }
  def popExpectedReturns():Pair[String,String]={
    if(expectedReturns == Nil){
      return null
    }
    var r = expectedReturns.head
    r
  }
  
  
  //functions related to teh current mehod and the stack of method invocations
  def CM():String={
    if(methInv == Nil){
      AlgBody.panic("getting the current method from an empty stack")
      "" //This should never happen
    }else{
    	this.methInv.head
    }
  }
  def onlyCMethod():String={
    var nm= this.CM()								//get the name of teh current meth form the CM
    nm = nm.substring(nm.indexOf(".")+1) 
    nm
  }
  def onlyCClass():String={
    var nm= this.CM()								//get the name of teh current meth form the CM
    nm = nm.substring(0,nm.indexOf(".")) 
    nm
  }
  
  
  
  //returns all teh interfaces of a given interface (itself and all teh things it implements)
  def allInterfs(s:String):List[String]={
    var ret:List[String] = s :: Nil
    for (el <- tabInterf.getEntryByName(s)._2){
      ret = ret ++ allInterfs (el) 
    }
    ret
  }
  
  
  
  //performs what is needed to differentiate an action e made from component n
  def singleAction(e:LowTraces,n:Int):String={
    e match {
      case r:Return =>{
        return "System.out.println("+n+");System.exit( "+n+" );"
      }
      case c:Callback =>{
        var str = "if( Helper.oc.getStep() == "+counter+" ) {\n" +
        		"System.out.println("+n+");System.exit( "+n+" ); " +
        		"}"
        tabMethBodies.addBody(tabAO.getClassOf(c.caller()),c.meth,str) 
        ""
      }
      case e:InputTrace=>{
        AlgBody.panic("received an input action instead of an output one")
        ""
      }
    }
  }
  
  def printoutVersion(n:Int)={
    tabMethBodies.printOut(n)
  }
  
}


object AlgBody {
  
  //checks whether s is a ground type
  def isNotGround(s:String):Boolean={
    return !(s.equalsIgnoreCase("void") ||s.equalsIgnoreCase("unit") || s.equalsIgnoreCase("boolean") || s.equalsIgnoreCase("integer"))
  }
  
  //halt abruptly
  def panic(s:String)={
    println(s)
    System.exit(99)
  }
}