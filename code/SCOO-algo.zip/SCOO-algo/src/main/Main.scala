package main

import java.io._
import dataStructures._

object Main {
  
  val SMA = "stMon"
  val SCBA = "stCaBa"
  var cn = 0

  def main(args: Array[String]): Unit = {
    
    //Different internal object communicated as parameter of a callback:
    var l1 = (new Call("createMonitor",SMA::Nil))::(new Return("o1"))::(new Call("setCallbacker", "o1"::"o"::Nil))::(new Callback("callback","o"::"o1"::Nil)):: Nil // (1 returns itself) 
	var l2 = (new Call("createMonitor",SMA::Nil))::(new Return("o1"))::(new Call("setCallbacker", "o1"::"o"::Nil))::(new Callback("callback","o"::"o2"::Nil)):: Nil // (2 returns a new object)
	
	execute(l1,l2)
   
	//Different ground-typed value communicated as parameter of a callback:
	l1 = (new Call("createMonitor",SMA::Nil))::(new Return("o1"))::(new Call("setCallbacker", "o1"::"null"::Nil)):: (new Callback("createCallbacker",Main.SCBA::Nil)):: (new Returnback("o")) :: (new Callback("callTwo", "o"::"0"::Nil)) :: Nil // (buffer of 1 == "0")
	l2 = (new Call("createMonitor",SMA::Nil))::(new Return("o1"))::(new Call("setCallbacker", "o1"::"null"::Nil)):: (new Callback("createCallbacker",Main.SCBA::Nil)):: (new Returnback("o")) :: (new Callback("callTwo", "o"::"1"::Nil)) :: Nil // (buffer of 2 == "1")
	
	execute(l1,l2) 
	
	//Different ground-typed value returned:
	l1 = (new Call("createMonitor",SMA::Nil))::(new Return("o1")):: (new Call("isLocked","o1"::Nil)) :: (new Return("1"))::Nil // (1 starts locked)
	l2 = (new Call("createMonitor",SMA::Nil))::(new Return("o1")):: (new Call("isLocked","o1"::Nil)) :: (new Return("0"))::Nil //(2 starts unlocked)
	
	execute(l1,l2) 
	
	//Different result from the same action being invoked later
	l1 = (new Call("createMonitor",SMA::Nil))::(new Return("o1")):: (new Call("lock","o1"::Nil)):: (new Return ("1")) :: (new Call("lock", "o1"::Nil)) ::(new Return("0"))::Nil // (1 allows to lock only once) 
	l2 = (new Call("createMonitor",SMA::Nil))::(new Return("o1")):: (new Call("lock","o1"::Nil)):: (new Return ("1")) :: (new Call("lock", "o1"::Nil)) ::(new Return("1"))::Nil // (1 allows to lock only once)
	
	execute(l1,l2) 
	
	//Different object on which a callback is performed
	l1 = (new Call("createMonitor",SMA::Nil))::(new Return("o1")) :: (new Call ("addCallBackers", "o1"::"e1"::"e2"::Nil))::(new Callback("callThree", "e1"::"o1"::Nil)) ::Nil// (1 calls on e1 with self)
	l2 = (new Call("createMonitor",SMA::Nil))::(new Return("o1")) :: (new Call ("addCallBackers", "o1"::"e1"::"e2"::Nil))::(new Callback("callThree", "e2"::"o1"::Nil)) ::Nil//(2 calls on e2 with self)
	
	execute(l1,l2) 
	
	//Different length
	l1 = (new Call("createMonitor",SMA::Nil))::(new Return("o1")) :: (new Call ("addCallBackers", "o1"::"null"::"e2"::Nil))::Nil //(1 calls to system exit)
	l2 = (new Call("createMonitor",SMA::Nil))::(new Return("o1")) :: (new Call ("addCallBackers", "o1"::"null"::"e2"::Nil))::(new Callback("callThree","e2"::"o1"::Nil)) :: Nil// (2 calls back)
	
	execute(l1,l2) 
	
	//Different actions
	l1 = (new Call("createMonitor",SMA::Nil))::(new Return("o1")) :: (new Call ("addCallBackers", "o1"::"e1"::"e1"::Nil)):: (new Return("")):: Nil//            (1 returns when both args are the same)
	l2 = (new Call("createMonitor",SMA::Nil))::(new Return("o1")) :: (new Call ("addCallBackers", "o1"::"e1"::"e1"::Nil)):: (new Callback ("callThree", "e1"::"o1"::Nil))::Nil// (2 does not care)
	 
	execute(l1,l2) 
    
	//Different method being callbacked 
	l1 = (new Call("createMonitor",SMA::Nil))::(new Return("o1")) :: (new Call ("addCallBackers", "o1"::"e1"::"null"::Nil))::(new Callback("callThree", "e1"::"o1"::Nil))::Nil//     (1 calls back to callThree)
	l2 = (new Call("createMonitor",SMA::Nil))::(new Return("o1")) :: (new Call ("addCallBackers", "o1"::"e1"::"null"::Nil))::(new Callback("createCallBacker","e1"::Nil))::Nil// (2 calls back to the constructor)
	
	execute(l1,l2) 
	
	//Different parameters in a callback. Parameters are external object allocated by the component
	l1 = (new Call("createMonitor",SMA::Nil))::(new Return("o1")) :: (new Call("trick", "o1"::"0"::Nil)):: (new Callback("createCallbacker",SCBA::Nil)):: (new Returnback("e1")) :: (new Callback("createCallbacker", SCBA::Nil)):: (new Returnback("e2")):: (new Callback("trickBack","e1"::"e1"::"e2"::Nil))::Nil// (1 calls back with e1 e2)
	l2 = (new Call("createMonitor",SMA::Nil))::(new Return("o1")) :: (new Call("trick", "o1"::"0"::Nil)):: (new Callback("createCallbacker",SCBA::Nil)):: (new Returnback("e1")) :: (new Callback("createCallbacker", SCBA::Nil)):: (new Returnback("e2")):: (new Callback("trickBack","e1"::"e2"::"e1"::Nil))::Nil// (2 calls back with e2 e1)
	
	execute(l1,l2) 
	
	//Different returned value. Returned value is an external object allocated by the component
	l1 = (new Call("createMonitor",SMA::Nil))::(new Return("o1"))::(new Call("trick","o1"::"1"::Nil))::(new Callback("createCallbacker",SCBA::Nil)):: (new Returnback("e1")) :: (new Callback("createCallbacker", SCBA::Nil)):: (new Returnback("e2")):: (new Return("e2"))::Nil// (1 returns the second object)
	l2 = (new Call("createMonitor",SMA::Nil))::(new Return("o1"))::(new Call("trick","o1"::"1"::Nil))::(new Callback("createCallbacker",SCBA::Nil)):: (new Returnback("e1")) :: (new Callback("createCallbacker", SCBA::Nil)):: (new Returnback("e2")):: (new Return("e1"))::Nil //(2 returns the first object)
	
	execute(l1,l2) 
	
	//Different returned value from method call to an internally allocated object
	l1 = (new Call("createMonitor",SMA::Nil))::(new Return("o1")):: (new Call("spawn","o1"::Nil)):: (new Return("o2")):: (new Call("isLocked","o2"::Nil)) :: (new Return("1"))::Nil//  (1 starts locked)
	l2 = (new Call("createMonitor",SMA::Nil))::(new Return("o1")):: (new Call("spawn","o1"::Nil)):: (new Return("o2")):: (new Call("isLocked","o2"::Nil)) :: (new Return("0"))::Nil// (2 starts unlocked)
	
	execute(l1,l2)
	
  }
  
   /*
     * this is called for all pairs of traces,
     * this runs the algorithm,												//DONE
     *  it creates the text in CallBacker_c and Tester						//DONE
     * then it modifies the callbacker_c and Tester to import the p_e_1		//DONE
     * then it runs the main in Tester,										//DONE
     *  and it asserts that it will return 1
     * then it modifies the callbacker_c and Tester to import the p_e_2		//DONE
     * then it runs the main, 
     *  and it asserts that it will return 2
     * 
     * then it places those copies of Callbacker_C and Tester in a folder	//DONE
     */
  def execute(l1:List[LowTraces],l2:List[LowTraces]):Unit ={
    cn += 1
    println("Execution number "+cn)
    println(l1)
    println(l2)
    var a = new AlgBody()
    a.diff(l1,l2)
    a.printoutVersion(1)
    println("Compile the shit: javac algout/*.java") // javac algout/*.java
    System.in.read()
    var p6 = Runtime.getRuntime().exec("java algOut/Tester")
    p6.waitFor()
    var ex = 3
    if(cn == 6){ //no distincion possible on different length with shorter trace
      ex=0
    }
    if(p6.exitValue()!= ex){	//TODO does not work
      println("Failed recognition of component 1 at trace "+cn +" found "+p6.exitValue())
      System.exit(0)
    }
    println("Component 1 at trace "+cn+" detected!")
    //moveToProd(1)
    println("Remove  the shit: rm algOut/*.class")
    System.in.read()
    
    a.printoutVersion(2)
    println("Compile the shit: javac algout/*.java") // javac algout/*.java
    System.in.read()
    var p3= Runtime.getRuntime().exec("java algOut/Tester")
    p3.waitFor()
    if(p3.exitValue()!= 2){//TODO does not work
      println("Failed recognition of component 2 at trace "+cn +" found "+p3.exitValue())
      System.exit(0)
    }
    println("Component 2 at trace "+cn+" detected!")
    //moveToProd(2)
    println("Remove  the shit: rm algOut/*.class")
    System.in.read()
    println("####################################################################")
    println("####################################################################")
  }

  
  def moveToProd(n:Int)={
    
    var src = new File("./algOut/Tester.java")
    var dest = new File("./../bin/"+cn+"/"+n+"/Tester.java")
    new FileOutputStream(dest) getChannel() transferFrom(new FileInputStream(src) getChannel, 0, Long.MaxValue )
    src = new File("./algOut/CallBacker_c.java")
    dest = new File("./../bin/"+cn+"/"+n+"/CallBacker_c.java")
    new FileOutputStream(dest) getChannel() transferFrom(new FileInputStream(src) getChannel, 0, Long.MaxValue )
    
  }
}