package main

object FreshNamer {

  private var n=0
  
  def getFreshName():String={
    var ret = "o"+n
    n = n+1
    ret
  }
    
}