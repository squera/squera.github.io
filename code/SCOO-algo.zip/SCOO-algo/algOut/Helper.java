package algOut;

import java.util.ArrayList;

public class Helper {
	public static Helper oc = new Helper();
	
	private int step =0;
	private ArrayList<Listable> objects = new ArrayList<Listable>(0);
	private ArrayList<Intern> internals = new ArrayList<Intern> (0);
	
	public int getStep() {
		return step; 
	}
	public void incrementStep() {
		step=step+ 1;
		return ; 
	}	
	public Listable getExternalByNameAndType(String a,String b){
		for(Listable ll : objects){
			if(ll.getName().equalsIgnoreCase(a) && ll.getType().equalsIgnoreCase(b)){
				return ll;
			}
		}
		return null;
	}
	public void registerObject(Listable o){
		objects.add(o); 
		return;
	}

	public static Helper getHelper(){
		if(oc == null){
			oc = new Helper();
		}
		return oc;
	}
	
	public Object getInternalByName(String n){
		for (Intern o : internals){
			if(o.lln.equalsIgnoreCase(n)){
				return o.obj;
			}
		}
		return null;
	}
	
	public String getInternalByObject(Object o){
		for (Intern ob : internals){
			if(ob.obj == o){
				return ob.lln;
			}
		}
		return "";
	}
	
	public void addInternalObject(String n, String t, Object o){
		internals.add(new Intern(n,t,o));
	}
	
}
