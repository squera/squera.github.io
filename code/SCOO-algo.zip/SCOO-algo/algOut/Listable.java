package algOut;

import algOut.Helper;

public class Listable {

	String name=""; 
	String type ="";
	
	public String getName(){
		return name;
	}
	public void setName(String n){
		name =n;
		return; 
	}
	public String getType(){
		return type; 
	}
	public void setType(String t){
		type=t;
		return;
	}
	public void setOcAndNameAndRegister(String v, String t) {
		this.setName(v);
		this.setType(t); 
		Helper.oc.registerObject(this);
		return;
	}
}
