package algOut;

import importPackage.CallBacker;
import p_i.*;
import p_e_2.*;

public class Tester extends Listable {

public static void main(String[] args) {
if ( Helper.oc.getStep() == 0 ) {
	Helper.oc.incrementStep();
	Monitor o20 = 	CPUMonitor.staticMonitor.createMonitor(  );
	Helper.oc.incrementStep();
	Helper.oc.addInternalObject( "o1" , "Monitor" , o20 );

}
if ( Helper.oc.getStep() == 2 ) {
	Helper.oc.incrementStep();
	Monitor o21 = 	( ( Monitor ) Helper.oc.getInternalByName( "o1" ) ).spawn(  );
	Helper.oc.incrementStep();
	Helper.oc.addInternalObject( "o2" , "Monitor" , o21 );

}
if ( Helper.oc.getStep() == 4 ) {
	Helper.oc.incrementStep();
	Boolean o22 = 	( ( Monitor ) Helper.oc.getInternalByName( "o2" ) ).isLocked(  );
	if ( o22 == true ) { System.exit(3); } else { System.exit(2); }

}

}
}
