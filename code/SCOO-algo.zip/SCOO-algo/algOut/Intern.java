package algOut;

public class Intern {
	
	String lln = "";
	String typ = "";
	Object obj = null;

	public Intern(String s, String t, Object o){
		lln=s;
		typ=t;
		obj=o;
	}
}
