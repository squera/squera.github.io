package algOut; 
import algOut.Listable;
import p_i.*;
import importPackage.CallBacker;
import p_e_2.*;

public class CallBacker_c extends Listable implements CallBacker {

public static CallBacker_c staticCallBacker = new CallBacker_c();

public void trickBack( CallBacker c1, CallBacker c2 ) {

}
public CallBacker createCallBacker(  ) {

return null;
}
public void callThree( Monitor m ) {

}
public void callTwo( Integer s ) {

}
public void callback( Monitor m ) {

}
public CallBacker defaultCreateClass_CallBacker(){
	if(this == CallBacker_c.staticCallBacker){
		return new CallBacker_c();
	}
//This should never happen actually
	return new CallBacker_c();
}
}
